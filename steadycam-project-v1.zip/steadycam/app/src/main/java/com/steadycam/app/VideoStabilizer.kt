package com.steadycam.app

import android.content.ContentValues
import android.content.Context
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import java.nio.ByteBuffer
import java.util.stream.IntStream
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// =====================================================================
//  ระบบกันสั่นวิดีโอที่เขียนเอง (ไม่พึ่งฮาร์ดแวร์ OIS/EIS ของเครื่อง) ทำงานหลังอัดเสร็จ
//
//  ขั้นตอน
//   1) ถอดรหัสวิดีโอทีละเฟรม -> ย่อภาพ -> หาการเคลื่อนไหวของกล้องระหว่างเฟรมด้วย block matching
//      (แบ่งภาพเป็นบล็อก ค้นหาตำแหน่งที่ตรงกันในเฟรมถัดไป ละเอียดระดับเศษพิกเซล)
//      แล้วประมาณเป็น "เลื่อน X, เลื่อน Y, หมุน" ด้วยกำลังสองน้อยสุดแบบตัดค่าผิดปกติทิ้ง
//   2) สะสมเป็นเส้นทางกล้อง แล้วทำให้เรียบด้วย Gaussian (แบบสองทิศทาง เพราะมีทั้งคลิปให้ดูล่วงหน้า)
//      ส่วนต่างระหว่างเส้นทางเรียบกับเส้นทางจริง = ค่าที่ต้องชดเชยของแต่ละเฟรม
//   3) ถอดรหัสอีกรอบ ชดเชยเฟรมด้วยการเลื่อน+หมุน+ซูมเข้าเล็กน้อย (bilinear บน CPU หลายเธรด)
//      เข้ารหัสเป็น H.264 ใหม่ และคัดลอกแทร็กเสียงเดิมไปตรง ๆ
//  ทั้งหมดใช้ API มาตรฐานของ Android เท่านั้น ไม่ใช้ OpenGL (เลี่ยงปัญหาวิดีโอดำที่เคยเจอ)
// =====================================================================

enum class Strength(val label: String, val zoom: Double, val sigmaSec: Double, val desc: String) {
    LIGHT("เบา", 1.06, 0.30, "ครอปน้อย เก็บมุมภาพไว้มาก เหมาะกับมือค่อนข้างนิ่งอยู่แล้ว"),
    MEDIUM("กลาง", 1.12, 0.60, "สมดุลที่สุด เหมาะกับถือกล้องเดิน/ถือมือเปล่าทั่วไป"),
    STRONG("แรง", 1.20, 1.00, "นิ่งสุดแนว gimbal ครอปมากขึ้น เหมาะกับคลิปที่สั่นหนัก")
}

class StabCancelled : Exception()

data class StabResult(val uri: Uri?, val error: String?)

object VideoStabilizer {

    fun stabilize(
        context: Context,
        src: Uri,
        srcName: String,
        strength: Strength,
        onProgress: (Float, String) -> Unit,
        isCancelled: () -> Boolean
    ): StabResult {
        val temp = File(context.cacheDir, "stab_${System.currentTimeMillis()}.mp4")
        try {
            process(context, src, temp, strength, onProgress, isCancelled)
            onProgress(0.99f, "กำลังบันทึกลงเครื่อง")
            val base = srcName.substringBeforeLast('.').removePrefix("STAB_")
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "STAB_$base.mp4")
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/SteadyCam")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val out = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: return StabResult(null, "สร้างไฟล์ผลลัพธ์ในเครื่องไม่ได้")
            return try {
                context.contentResolver.openOutputStream(out)?.use { o -> temp.inputStream().use { it.copyTo(o) } }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                context.contentResolver.update(out, done, null, null)
                StabResult(out, null)
            } catch (e: Exception) {
                runCatching { context.contentResolver.delete(out, null, null) }
                StabResult(null, "บันทึกไฟล์ไม่สำเร็จ: ${e.message}")
            }
        } catch (c: StabCancelled) {
            return StabResult(null, null)
        } catch (t: Throwable) {
            return StabResult(null, "${t.javaClass.simpleName}: ${t.message}")
        } finally {
            temp.delete()
        }
    }

    // ------------------------------------------------------------------
    private fun process(
        context: Context,
        src: Uri,
        outFile: File,
        strength: Strength,
        onProgress: (Float, String) -> Unit,
        isCancelled: () -> Boolean
    ) {
        val info = readInfo(context, src)

        // ---------- ผ่านที่ 1: วัดการเคลื่อนไหว ----------
        val ptsList = ArrayList<Long>()
        val motions = ArrayList<FloatArray>()
        var estimator: MotionEstimator? = null
        var ew = 0
        var eh = 0
        decodeAll(context, src, isCancelled) { _, t, img ->
            if (estimator == null) {
                ew = img.width and 1.inv()
                eh = img.height and 1.inv()
                estimator = MotionEstimator(ew, eh)
            }
            motions.add(estimator!!.next(img))
            ptsList.add(t)
            if (info.durationUs > 0) {
                onProgress(0.35f * min(1f, t.toFloat() / info.durationUs), "วิเคราะห์การสั่นของกล้อง")
            }
        }
        val n = motions.size
        if (n < 3) throw IllegalStateException("วิดีโอสั้นเกินไปหรืออ่านเฟรมไม่ได้")

        val spanUs = (ptsList[n - 1] - ptsList[0]).coerceAtLeast(1L)
        val fps = ((n - 1) * 1_000_000.0 / spanUs).coerceIn(5.0, 120.0)

        // ---------- คำนวณเส้นทางกล้องและค่าชดเชย ----------
        val px = DoubleArray(n)
        val py = DoubleArray(n)
        val pa = DoubleArray(n)
        for (i in 1 until n) {
            px[i] = px[i - 1] + motions[i][0]
            py[i] = py[i - 1] + motions[i][1]
            pa[i] = pa[i - 1] + motions[i][2]
        }
        val sigma = max(1.0, strength.sigmaSec * fps)
        val sx = gaussianSmooth(px, sigma)
        val sy = gaussianSmooth(py, sigma)
        val sa = gaussianSmooth(pa, sigma)

        val z = strength.zoom
        val maxRot = 0.05 // ~2.9 องศา
        val corr = Array(n) { i ->
            val phi = (sa[i] - pa[i]).coerceIn(-maxRot, maxRot)
            val c = cos(abs(phi))
            val s = sin(abs(phi))
            val slackX = (ew / 2.0 - (ew / (2 * z)) * c - (eh / (2 * z)) * s).coerceAtLeast(0.0)
            val slackY = (eh / 2.0 - (eh / (2 * z)) * c - (ew / (2 * z)) * s).coerceAtLeast(0.0)
            doubleArrayOf(
                (sx[i] - px[i]).coerceIn(-slackX, slackX),
                (sy[i] - py[i]).coerceIn(-slackY, slackY),
                phi
            )
        }

        // ---------- ผ่านที่ 2: ชดเชย + เข้ารหัส ----------
        val cw = ew / 2
        val ch = eh / 2
        val inY = ByteArray(ew * eh)
        val inU = ByteArray(cw * ch)
        val inV = ByteArray(cw * ch)
        val outY = ByteArray(ew * eh)
        val outU = ByteArray(cw * ch)
        val outV = ByteArray(cw * ch)

        val bitrate = ((if (info.bitrate > 0) info.bitrate * 1.15 else ew * eh * fps * 0.10)
            .toLong().coerceIn(2_000_000L, 50_000_000L)).toInt()
        val audio = openAudio(context, src)
        val writer = Writer(ew, eh, fps.toInt().coerceAtLeast(1), bitrate, outFile.absolutePath, info.rotation, audio?.second)
        try {
            decodeAll(context, src, isCancelled) { idx, t, img ->
                val c = corr[min(idx, n - 1)]
                readPlane(img.planes[0], ew, eh, inY)
                readPlane(img.planes[1], cw, ch, inU)
                readPlane(img.planes[2], cw, ch, inV)
                val cosP = cos(c[2])
                val sinP = sin(c[2])
                warp(inY, outY, ew, eh, (ew - 1) / 2.0, (eh - 1) / 2.0, z, cosP, sinP, c[0], c[1])
                warp(inU, outU, cw, ch, (cw - 1) / 2.0, (ch - 1) / 2.0, z, cosP, sinP, c[0] / 2, c[1] / 2)
                warp(inV, outV, cw, ch, (cw - 1) / 2.0, (ch - 1) / 2.0, z, cosP, sinP, c[0] / 2, c[1] / 2)
                writer.write(outY, outU, outV, t)
                if (info.durationUs > 0) {
                    onProgress(0.35f + 0.63f * min(1f, t.toFloat() / info.durationUs), "กำลังกันสั่นและเข้ารหัสวิดีโอ")
                }
            }
            writer.finish(audio?.first)
        } finally {
            writer.release()
            audio?.first?.release()
        }
    }

    // ------------------------------------------------------------------
    private class SrcInfo(val durationUs: Long, val rotation: Int, val bitrate: Int)

    private fun readInfo(context: Context, uri: Uri): SrcInfo {
        var dur = 0L
        var rot = 0
        var br = 0
        runCatching {
            val r = MediaMetadataRetriever()
            r.setDataSource(context, uri)
            dur = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
            rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            br = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0
            r.release()
        }
        if (rot != 0 && rot != 90 && rot != 180 && rot != 270) rot = 0
        return SrcInfo(dur, rot, br)
    }

    private fun openAudio(context: Context, uri: Uri): Pair<MediaExtractor, MediaFormat>? {
        return runCatching {
            val ex = MediaExtractor()
            context.contentResolver.openFileDescriptor(uri, "r")?.use { ex.setDataSource(it.fileDescriptor) }
                ?: return@runCatching null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    ex.selectTrack(i)
                    return@runCatching Pair(ex, f)
                }
            }
            ex.release()
            null
        }.getOrNull()
    }

    // ถอดรหัสวิดีโอทุกเฟรมตามลำดับการแสดงผล ส่งเฟรม YUV ให้ callback
    private fun decodeAll(
        context: Context,
        uri: Uri,
        isCancelled: () -> Boolean,
        onFrame: (Int, Long, Image) -> Unit
    ) {
        val ex = MediaExtractor()
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("เปิดไฟล์วิดีโอไม่ได้")
        var dec: MediaCodec? = null
        try {
            ex.setDataSource(pfd.fileDescriptor)
            var track = -1
            for (i in 0 until ex.trackCount) {
                if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) {
                    track = i
                    break
                }
            }
            if (track < 0) throw IllegalStateException("ไม่พบแทร็กวิดีโอ")
            ex.selectTrack(track)
            val format = ex.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME)!!
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            dec = MediaCodec.createDecoderByType(mime)
            dec.configure(format, null, null, 0)
            dec.start()

            val bi = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var idx = 0
            while (!outputDone) {
                if (isCancelled()) throw StabCancelled()
                if (!inputDone) {
                    val i = dec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = dec.getInputBuffer(i)!!
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) {
                            dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(i, 0, size, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = dec.dequeueOutputBuffer(bi, 10_000)
                if (o >= 0) {
                    if (bi.size > 0 && (bi.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        val img = dec.getOutputImage(o)
                            ?: throw IllegalStateException("ตัวถอดรหัสของเครื่องไม่ให้ภาพ YUV (อาจเป็นวิดีโอ HDR/10 บิต ซึ่งยังไม่รองรับ)")
                        try {
                            onFrame(idx++, bi.presentationTimeUs, img)
                        } finally {
                            img.close()
                        }
                    }
                    dec.releaseOutputBuffer(o, false)
                    if ((bi.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                }
            }
        } finally {
            runCatching { dec?.stop() }
            runCatching { dec?.release() }
            ex.release()
            runCatching { pfd.close() }
        }
    }

    // ------------------------------------------------------------------
    //  ตัวช่วยอ่าน/เขียนระนาบภาพ YUV (รองรับ rowStride/pixelStride ทุกแบบ)
    // ------------------------------------------------------------------
    private fun readPlane(p: Image.Plane, w: Int, h: Int, out: ByteArray) {
        val buf = p.buffer
        val rs = p.rowStride
        val ps = p.pixelStride
        if (ps == 1) {
            for (r in 0 until h) {
                buf.position(r * rs)
                buf.get(out, r * w, w)
            }
        } else {
            val tmp = ByteArray(rs)
            for (r in 0 until h) {
                val start = r * rs
                val len = min(rs, buf.limit() - start)
                buf.position(start)
                buf.get(tmp, 0, len)
                val o = r * w
                for (c in 0 until w) out[o + c] = tmp[c * ps]
            }
        }
    }

    private fun writePlane(p: Image.Plane, src: ByteArray, w: Int, h: Int) {
        val buf = p.buffer
        val rs = p.rowStride
        val ps = p.pixelStride
        if (ps == 1) {
            for (r in 0 until h) {
                buf.position(r * rs)
                buf.put(src, r * w, w)
            }
        } else {
            val lim = buf.limit()
            for (r in 0 until h) {
                val base = r * rs
                val o = r * w
                for (c in 0 until w) {
                    val at = base + c * ps
                    if (at < lim) buf.put(at, src[o + c])
                }
            }
        }
    }

    // ------------------------------------------------------------------
    //  ชดเชยภาพ: dest -> source (inverse mapping) เลื่อน+หมุน+ซูม ด้วย bilinear หลายเธรด
    //   src = c + R(-phi) * ((dest - c)/z - t)
    // ------------------------------------------------------------------
    private fun warp(
        src: ByteArray, dst: ByteArray, w: Int, h: Int,
        cx: Double, cy: Double, z: Double, cosP: Double, sinP: Double, tx: Double, ty: Double
    ) {
        val invZ = 1.0 / z
        val maxX = w - 1.001
        val maxY = h - 1.001
        IntStream.range(0, h).parallel().forEach { y ->
            val v = (y - cy) * invZ - ty
            val row = y * w
            for (x in 0 until w) {
                val u = (x - cx) * invZ - tx
                var sxp = cx + cosP * u + sinP * v
                var syp = cy - sinP * u + cosP * v
                if (sxp < 0.0) sxp = 0.0 else if (sxp > maxX) sxp = maxX
                if (syp < 0.0) syp = 0.0 else if (syp > maxY) syp = maxY
                val x0 = sxp.toInt()
                val y0 = syp.toInt()
                val fx = (sxp - x0).toFloat()
                val fy = (syp - y0).toFloat()
                val i = y0 * w + x0
                val a = src[i].toInt() and 0xFF
                val b = src[i + 1].toInt() and 0xFF
                val c = src[i + w].toInt() and 0xFF
                val d = src[i + w + 1].toInt() and 0xFF
                val top = a + (b - a) * fx
                val bot = c + (d - c) * fx
                dst[row + x] = (top + (bot - top) * fy + 0.5f).toInt().toByte()
            }
        }
    }

    // ทำเส้นทางให้เรียบด้วย Gaussian สองทิศทาง ขอบใช้การสะท้อนแบบ odd (รักษาแนวโน้มปลายเส้น)
    private fun gaussianSmooth(x: DoubleArray, sigma: Double): DoubleArray {
        val n = x.size
        val r = ceil(3 * sigma).toInt().coerceAtLeast(1)
        val k = DoubleArray(2 * r + 1) { exp(-((it - r) * (it - r)) / (2 * sigma * sigma)) }
        val sum = k.sum()
        fun at(i: Int): Double = when {
            i < 0 -> if (-i < n) 2 * x[0] - x[-i] else x[0]
            i >= n -> { val j = 2 * (n - 1) - i; if (j >= 0) 2 * x[n - 1] - x[j] else x[n - 1] }
            else -> x[i]
        }
        return DoubleArray(n) { i ->
            var s = 0.0
            for (j in -r..r) s += k[j + r] * at(i + j)
            s / sum
        }
    }

    // ------------------------------------------------------------------
    //  ตัวเข้ารหัส H.264 + muxer (+ คัดลอกเสียงเดิม)
    // ------------------------------------------------------------------
    private class Writer(
        private val w: Int, private val h: Int, fps: Int, bitrate: Int,
        outPath: String, rotation: Int, private val audioFormat: MediaFormat?
    ) {
        private val codec: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        private val muxer = MediaMuxer(outPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        private val bi = MediaCodec.BufferInfo()
        private var vTrack = -1
        private var aTrack = -1
        private var started = false
        private var lastPts = 0L
        private var released = false

        init {
            val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            muxer.setOrientationHint(rotation)
        }

        fun write(y: ByteArray, u: ByteArray, v: ByteArray, ptsUs: Long) {
            var tries = 0
            while (true) {
                drain(false)
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    val img = codec.getInputImage(i)
                        ?: throw IllegalStateException("ตัวเข้ารหัสของเครื่องไม่รับภาพ YUV แบบ flexible")
                    writePlane(img.planes[0], y, w, h)
                    writePlane(img.planes[1], u, w / 2, h / 2)
                    writePlane(img.planes[2], v, w / 2, h / 2)
                    codec.queueInputBuffer(i, 0, w * h * 3 / 2, ptsUs, 0)
                    lastPts = ptsUs
                    break
                }
                if (++tries > 2000) throw IllegalStateException("ตัวเข้ารหัสไม่ตอบสนอง")
            }
            drain(false)
        }

        private fun drain(untilEos: Boolean) {
            var idle = 0
            while (true) {
                val o = codec.dequeueOutputBuffer(bi, if (untilEos) 10_000 else 0)
                if (o == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!untilEos) return
                    if (++idle > 1000) throw IllegalStateException("ตัวเข้ารหัสไม่จบงาน")
                    continue
                }
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    vTrack = muxer.addTrack(codec.outputFormat)
                    if (audioFormat != null) aTrack = muxer.addTrack(audioFormat)
                    muxer.start()
                    started = true
                    continue
                }
                if (o < 0) continue
                idle = 0
                val buf: ByteBuffer = codec.getOutputBuffer(o)!!
                if ((bi.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) bi.size = 0
                if (bi.size > 0 && started) {
                    buf.position(bi.offset)
                    buf.limit(bi.offset + bi.size)
                    muxer.writeSampleData(vTrack, buf, bi)
                }
                codec.releaseOutputBuffer(o, false)
                if ((bi.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }

        fun finish(audioEx: MediaExtractor?) {
            var tries = 0
            while (true) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    codec.queueInputBuffer(i, 0, 0, lastPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
                drain(false)
                if (++tries > 2000) throw IllegalStateException("ปิดไฟล์วิดีโอไม่สำเร็จ")
            }
            drain(true)
            if (!started) throw IllegalStateException("ตัวเข้ารหัสไม่ได้สร้างข้อมูลวิดีโอ")
            if (audioEx != null && aTrack >= 0) {
                val cap = if (audioFormat!!.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE))
                    audioFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE).coerceAtLeast(64 * 1024) else 512 * 1024
                val abuf = ByteBuffer.allocate(cap)
                val ai = MediaCodec.BufferInfo()
                while (true) {
                    abuf.clear()
                    val size = audioEx.readSampleData(abuf, 0)
                    if (size < 0) break
                    ai.offset = 0
                    ai.size = size
                    ai.presentationTimeUs = audioEx.sampleTime
                    ai.flags = if ((audioEx.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    muxer.writeSampleData(aTrack, abuf, ai)
                    audioEx.advance()
                }
            }
            muxer.stop()
        }

        fun release() {
            if (released) return
            released = true
            runCatching { codec.stop() }
            runCatching { codec.release() }
            runCatching { muxer.release() }
        }
    }
}

// =====================================================================
//  ตัวประมาณการเคลื่อนไหวของกล้องระหว่างเฟรม (block matching + robust similarity fit)
//  คืนค่า [dx, dy, dθ] ของ "เนื้อภาพ" จากเฟรมก่อนหน้าไปเฟรมนี้ หน่วยพิกเซลความละเอียดเต็ม / เรเดียน
// =====================================================================
class MotionEstimator(private val fullW: Int, private val fullH: Int) {
    private val ds = max(1, fullW / 320)
    private val sw = fullW / ds
    private val sh = fullH / ds
    private var prev = ByteArray(sw * sh)
    private var cur = ByteArray(sw * sh)
    private var hasPrev = false

    private val B = 16
    private val R = 10
    private val step = B + 4
    private val cap = 512
    private val qx = FloatArray(cap)
    private val qy = FloatArray(cap)
    private val vx = FloatArray(cap)
    private val vy = FloatArray(cap)

    fun next(img: Image): FloatArray {
        downscale(img)
        var result = floatArrayOf(0f, 0f, 0f)
        if (hasPrev) {
            val n = matchBlocks()
            val fit = fit(n)
            if (fit != null) result = floatArrayOf(fit[0] * ds, fit[1] * ds, fit[2])
        }
        val t = prev; prev = cur; cur = t
        hasPrev = true
        return result
    }

    private fun downscale(img: Image) {
        val p = img.planes[0]
        val buf: ByteBuffer = p.buffer
        val rs = p.rowStride
        val hf = ds / 2
        for (y in 0 until sh) {
            val sy = y * ds
            for (x in 0 until sw) {
                val sx = x * ds
                val a = buf.get(sy * rs + sx).toInt() and 0xFF
                val b = buf.get(sy * rs + sx + hf).toInt() and 0xFF
                val c = buf.get((sy + hf) * rs + sx).toInt() and 0xFF
                val d = buf.get((sy + hf) * rs + sx + hf).toInt() and 0xFF
                cur[y * sw + x] = ((a + b + c + d) shr 2).toByte()
            }
        }
    }

    private fun sad(px: Int, py: Int, cx: Int, cy: Int, best: Int): Int {
        var s = 0
        var y = 0
        while (y < B) {
            val po = (py + y) * sw + px
            val co = (cy + y) * sw + cx
            var x = 0
            while (x < B) {
                s += abs((prev[po + x].toInt() and 0xFF) - (cur[co + x].toInt() and 0xFF))
                x += 2
            }
            if (s >= best) return s
            y += 2
        }
        return s
    }

    private fun matchBlocks(): Int {
        var n = 0
        var py = R
        while (py <= sh - B - R) {
            var px = R
            while (px <= sw - B - R) {
                // ข้ามบล็อกที่ไม่มีลายละเอียด (ท้องฟ้า/ผนังเรียบ) เพราะจับการเคลื่อนไหวไม่ได้
                var sum = 0
                var cnt = 0
                var y = 0
                while (y < B) {
                    var x = 0
                    while (x < B) { sum += prev[(py + y) * sw + px + x].toInt() and 0xFF; cnt++; x += 2 }
                    y += 2
                }
                val mean = sum / cnt
                var mad = 0
                y = 0
                while (y < B) {
                    var x = 0
                    while (x < B) { mad += abs((prev[(py + y) * sw + px + x].toInt() and 0xFF) - mean); x += 2 }
                    y += 2
                }
                if (mad / cnt >= 4 && n < cap) {
                    var best = Int.MAX_VALUE
                    var bdx = 0
                    var bdy = 0
                    for (dy in -R..R) {
                        for (dx in -R..R) {
                            val s = sad(px, py, px + dx, py + dy, best)
                            if (s < best) { best = s; bdx = dx; bdy = dy }
                        }
                    }
                    if (abs(bdx) < R && abs(bdy) < R) {
                        val s0 = best.toFloat()
                        val sxm = sad(px, py, px + bdx - 1, py + bdy, Int.MAX_VALUE).toFloat()
                        val sxp = sad(px, py, px + bdx + 1, py + bdy, Int.MAX_VALUE).toFloat()
                        val sym = sad(px, py, px + bdx, py + bdy - 1, Int.MAX_VALUE).toFloat()
                        val syp = sad(px, py, px + bdx, py + bdy + 1, Int.MAX_VALUE).toFloat()
                        val dxs = subpixel(sxm, s0, sxp)
                        val dys = subpixel(sym, s0, syp)
                        qx[n] = px + B / 2f - sw / 2f
                        qy[n] = py + B / 2f - sh / 2f
                        vx[n] = bdx + dxs
                        vy[n] = bdy + dys
                        n++
                    }
                }
                px += step
            }
            py += step
        }
        return n
    }

    private fun subpixel(m: Float, c: Float, p: Float): Float {
        val den = m - 2 * c + p
        if (den <= 1e-3f) return 0f
        return (0.5f * (m - p) / den).coerceIn(-0.5f, 0.5f)
    }

    // ประมาณ (tx, ty, θ) ของ  v = t + θ·perp(q)  ด้วยกำลังสองน้อยสุด ตัดจุดผิดปกติ (วัตถุเคลื่อนที่) ทิ้งซ้ำ ๆ
    private fun fit(n: Int): FloatArray? {
        if (n < 6) return null
        val use = BooleanArray(n) { true }
        val res = FloatArray(n)
        var out: FloatArray? = null
        for (iter in 0 until 3) {
            var m = 0
            var mqx = 0.0; var mqy = 0.0; var mvx = 0.0; var mvy = 0.0
            for (i in 0 until n) if (use[i]) { m++; mqx += qx[i]; mqy += qy[i]; mvx += vx[i]; mvy += vy[i] }
            if (m < 5) return out
            mqx /= m; mqy /= m; mvx /= m; mvy /= m
            var num = 0.0
            var den = 0.0
            for (i in 0 until n) if (use[i]) {
                val ax = qx[i] - mqx; val ay = qy[i] - mqy
                val bx = vx[i] - mvx; val by = vy[i] - mvy
                num += -ay * bx + ax * by
                den += ax * ax + ay * ay
            }
            val th = if (den > 1e-6) num / den else 0.0
            val tx = mvx + th * mqy
            val ty = mvy - th * mqx
            out = floatArrayOf(tx.toFloat(), ty.toFloat(), th.toFloat())
            val r = FloatArray(m)
            var k = 0
            for (i in 0 until n) {
                val ex = vx[i] - (tx + th * (-qy[i]))
                val ey = vy[i] - (ty + th * qx[i])
                res[i] = hypot(ex, ey).toFloat()
                if (use[i]) r[k++] = res[i]
            }
            r.sort()
            val thr = max(0.7f, 2f * r[m / 2])
            for (i in 0 until n) use[i] = res[i] <= thr
        }
        return out
    }
}
