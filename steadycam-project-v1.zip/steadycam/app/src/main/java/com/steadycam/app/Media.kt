package com.steadycam.app

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** ไฟล์ภาพ/วิดีโอหนึ่งรายการจากแกลเลอรีของเครื่อง */
class MediaItem(
    val uri: Uri,
    val isVideo: Boolean,
    val name: String,
    val dateAdded: Long,
    val durationMs: Long,
    val path: String
) {
    /** ผลลัพธ์จากระบบกันสั่นของแอปนี้ */
    val isStabilized: Boolean get() = path.startsWith("Movies/SteadyCam")
}

/** อ่านภาพและวิดีโอทั้งหมดในเครื่อง (ใหม่สุดก่อน) */
fun queryMedia(context: Context): List<MediaItem> {
    val out = ArrayList<MediaItem>()
    fun query(base: Uri, isVideo: Boolean) {
        val proj = if (isVideo) arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.Video.VideoColumns.DURATION
        ) else arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.RELATIVE_PATH
        )
        runCatching {
            context.contentResolver.query(base, proj, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val dateCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val pathCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
                val durCol = if (isVideo) c.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION) else -1
                while (c.moveToNext()) {
                    out.add(
                        MediaItem(
                            ContentUris.withAppendedId(base, c.getLong(idCol)),
                            isVideo,
                            c.getString(nameCol) ?: "",
                            c.getLong(dateCol),
                            if (durCol >= 0) c.getLong(durCol) else 0L,
                            c.getString(pathCol) ?: ""
                        )
                    )
                }
            }
        }
    }
    query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false)
    query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
    return out.sortedByDescending { it.dateAdded }
}

/** โหลดภาพย่อ/ภาพขยายผ่านระบบของ Android (รองรับทั้งภาพและวิดีโอ หมุนตามทิศทางให้เอง) พร้อมแคช */
object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(48 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    suspend fun load(context: Context, uri: Uri, px: Int): Bitmap? {
        val key = "$uri@$px"
        cache.get(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching { context.contentResolver.loadThumbnail(uri, Size(px, px), null) }
                .getOrNull()
                ?.also { cache.put(key, it) }
        }
    }
}

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}
