package com.steadycam.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { SteadyTheme { PermissionGate() } }
    }
}

private fun neededPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

@Composable
private fun PermissionGate() {
    val ctx = LocalContext.current
    fun granted() = neededPermissions().all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }
    var ok by remember { mutableStateOf(granted()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ok = granted() }
    if (ok) {
        AppRoot()
    } else {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("SteadyCam", style = TextStyle(brush = AccentBrush, fontSize = 40.sp, fontWeight = FontWeight.Bold))
            Spacer(Modifier.height(12.dp))
            Text(
                "กันสั่นวิดีโอด้วยระบบของเราเอง\nต้องอนุญาตให้อ่านภาพและวิดีโอในเครื่องก่อน",
                color = TextDim, fontSize = 15.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(28.dp))
            Button(
                onClick = { launcher.launch(neededPermissions()) },
                colors = ButtonDefaults.buttonColors(containerColor = Violet),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("อนุญาตเข้าถึงแกลเลอรี", fontSize = 16.sp) }
            TextButton(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }) { Text("เปิดหน้าตั้งค่าแอป (ถ้ากดแล้วไม่ขึ้น)", color = TextDim, fontSize = 13.sp) }
        }
    }
}

/** สถานะการกันสั่นที่ทำงานอยู่ (อยู่ที่ระดับ Root เพื่อให้ทำต่อได้แม้ปิดหน้าดูภาพ) */
class StabState {
    var running by mutableStateOf(false)
    var progress by mutableFloatStateOf(0f)
    var phase by mutableStateOf("")
    var result by mutableStateOf<Uri?>(null)
    var error by mutableStateOf<String?>(null)
    @Volatile var cancel = false
}

class ViewerRequest(val list: List<MediaItem>, val index: Int)

@Composable
private fun AppRoot() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<MediaItem>?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    var viewer by remember { mutableStateOf<ViewerRequest?>(null) }
    val stab = remember { StabState() }

    LaunchedEffect(reload) { items = withContext(Dispatchers.IO) { queryMedia(ctx) } }

    // ระหว่างประมวลผลให้จอติดค้าง ไม่งั้นระบบอาจพักแอปแล้วงานหยุด
    LaunchedEffect(stab.running) {
        val w = (ctx as? Activity)?.window
        if (stab.running) w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    fun startStabilize(item: MediaItem, strength: Strength) {
        if (stab.running) return
        stab.cancel = false
        stab.progress = 0f
        stab.phase = "เตรียมการ"
        stab.result = null
        stab.error = null
        stab.running = true
        scope.launch {
            val res = withContext(Dispatchers.Default) {
                VideoStabilizer.stabilize(
                    ctx, item.uri, item.name, strength,
                    onProgress = { p, ph -> stab.progress = p; stab.phase = ph },
                    isCancelled = { stab.cancel }
                )
            }
            stab.running = false
            if (res.uri != null) { stab.result = res.uri; reload++ }
            else if (res.error != null) stab.error = res.error
        }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        val v = viewer
        if (v == null) {
            GalleryScreen(
                media = items, tab = tab, onTab = { tab = it },
                onOpen = { list, i -> viewer = ViewerRequest(list, i) }
            )
        } else {
            ViewerScreen(
                request = v,
                busy = stab.running,
                onClose = { viewer = null },
                onStabilize = { item, s -> startStabilize(item, s) }
            )
        }

        if (stab.running) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.8f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.padding(28.dp).clip(RoundedCornerShape(24.dp)).background(Surface1).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(stab.phase, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(16.dp))
                    LinearProgressIndicator(
                        progress = { stab.progress.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = Cyan, trackColor = Surface2
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("${(stab.progress * 100).toInt()}%", color = TextDim, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "ใช้เวลาตามความยาวและความละเอียดคลิป\nกรุณาเปิดแอปนี้ค้างไว้จนเสร็จ",
                        color = TextDim, fontSize = 12.sp, textAlign = TextAlign.Center
                    )
                    TextButton(onClick = { stab.cancel = true }) { Text("ยกเลิก", color = Danger) }
                }
            }
        }

        if (stab.result != null) {
            AlertDialog(
                onDismissRequest = { stab.result = null },
                containerColor = Surface1,
                title = { Text("กันสั่นเสร็จแล้ว", color = Color.White) },
                text = { Text("บันทึกไว้ในแท็บ \"เสถียรแล้ว\" (โฟลเดอร์ Movies/SteadyCam)", color = TextDim) },
                confirmButton = {
                    TextButton(onClick = { stab.result = null; viewer = null; tab = 2 }) { Text("ไปดูผลลัพธ์", color = Cyan) }
                },
                dismissButton = { TextButton(onClick = { stab.result = null }) { Text("ปิด", color = TextDim) } }
            )
        }
        stab.error?.let { msg ->
            AlertDialog(
                onDismissRequest = { stab.error = null },
                containerColor = Surface1,
                title = { Text("กันสั่นไม่สำเร็จ", color = Color.White) },
                text = { Text(msg, color = TextDim) },
                confirmButton = { TextButton(onClick = { stab.error = null }) { Text("ปิด", color = Cyan) } }
            )
        }
    }
}
