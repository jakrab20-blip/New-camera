package com.steadycam.app

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val TAB_NAMES = listOf("วิดีโอ", "รูปภาพ", "เสถียรแล้ว")

@Composable
fun GalleryScreen(
    media: List<MediaItem>?,
    tab: Int,
    onTab: (Int) -> Unit,
    onOpen: (List<MediaItem>, Int) -> Unit
) {
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
            Text("SteadyCam", style = TextStyle(brush = AccentBrush, fontSize = 30.sp, fontWeight = FontWeight.Bold))
            Text("ภาพและวิดีโอในเครื่อง · แตะวิดีโอเพื่อกันสั่น", color = TextDim, fontSize = 13.sp)
        }
        Row(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                .clip(RoundedCornerShape(16.dp)).background(Surface1).padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            TAB_NAMES.forEachIndexed { i, name ->
                val sel = i == tab
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                        .background(if (sel) Violet else Color.Transparent)
                        .clickable { onTab(i) }.padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(name, color = if (sel) Color.White else TextDim, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        if (media == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Cyan) }
        } else {
            val shown = when (tab) {
                0 -> media.filter { it.isVideo && !it.isStabilized }
                1 -> media.filter { !it.isVideo }
                else -> media.filter { it.isStabilized }
            }
            if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        if (tab == 2) "ยังไม่มีวิดีโอที่กันสั่นแล้ว" else "ไม่พบไฟล์",
                        color = TextDim, fontSize = 15.sp
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxSize().navigationBarsPadding()
                ) {
                    items(shown, key = { it.uri.toString() }) { item ->
                        Thumb(item) { onOpen(shown, shown.indexOf(item)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun Thumb(item: MediaItem, onClick: () -> Unit) {
    val ctx = LocalContext.current
    var bmp by remember(item.uri) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(item.uri) { bmp = Thumbs.load(ctx, item.uri, 360) }
    Box(
        Modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(Surface2).clickable(onClick = onClick)
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(), contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
            )
        }
        if (item.isVideo) {
            Row(
                Modifier.align(Alignment.BottomStart).padding(6.dp).clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 7.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(13.dp))
                Text(formatDuration(item.durationMs), color = Color.White, fontSize = 11.sp)
            }
        }
        if (item.isStabilized) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).clip(CircleShape).background(Violet),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.AutoFixHigh, null, tint = Color.White, modifier = Modifier.size(14.dp)) }
        }
    }
}
