package com.steadycam.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay

@Composable
fun ViewerScreen(
    request: ViewerRequest,
    busy: Boolean,
    onClose: () -> Unit,
    onStabilize: (MediaItem, Strength) -> Unit
) {
    val ctx = LocalContext.current
    val list = request.list
    val pager = rememberPagerState(initialPage = request.index.coerceIn(0, (list.size - 1).coerceAtLeast(0))) { list.size }
    var showOptions by remember { mutableStateOf(false) }
    var strength by remember { mutableStateOf(Strength.MEDIUM) }
    BackHandler { onClose() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            val item = list[page]
            if (item.isVideo) VideoPage(item, active = pager.currentPage == page)
            else PhotoPage(item)
        }

        val current = list.getOrNull(pager.currentPage)

        // แถบบน: ปิด + ลำดับ
        Row(
            Modifier.align(Alignment.TopStart).fillMaxWidth().statusBarsPadding().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundButton(Icons.Rounded.Close, "ปิด") { onClose() }
            Spacer(Modifier.weight(1f))
            Text(
                "${pager.currentPage + 1} / ${list.size}",
                color = Color.White, fontSize = 13.sp,
                modifier = Modifier.clip(CircleShape).background(Color.Black.copy(alpha = 0.5f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }

        // แถบล่าง: แชร์ + ปุ่มกันสั่น (เฉพาะวิดีโอ)
        if (current != null) {
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (current.isVideo && !current.isStabilized) {
                    Row(
                        Modifier.weight(1f).height(52.dp).clip(RoundedCornerShape(26.dp))
                            .background(AccentBrush)
                            .clickable(enabled = !busy) { showOptions = true },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Rounded.AutoFixHigh, null, tint = Color.White, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.size(8.dp))
                        Text("กันสั่นวิดีโอนี้", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Spacer(Modifier.weight(1f))
                }
                RoundButton(Icons.Rounded.Share, "แชร์") { shareMedia(ctx, current) }
            }
        }

        if (showOptions && current != null) {
            AlertDialog(
                onDismissRequest = { showOptions = false },
                containerColor = Surface1,
                title = { Text("กันสั่นวิดีโอ", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Strength.values().forEach { s ->
                            val sel = s == strength
                            Column(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                    .background(if (sel) Surface2 else Color.Transparent)
                                    .border(1.5.dp, if (sel) Cyan else Surface2, RoundedCornerShape(14.dp))
                                    .clickable { strength = s }.padding(12.dp)
                            ) {
                                Text(s.label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                Text(s.desc, color = TextDim, fontSize = 12.sp)
                            }
                        }
                        Text(
                            "ระบบจะวิเคราะห์การสั่นแล้วชดเชยภาพ ซูมเข้าเล็กน้อยเพื่อซ่อนขอบ " +
                                "เก็บเป็นไฟล์ใหม่ ไม่แตะไฟล์ต้นฉบับ",
                            color = TextDim, fontSize = 12.sp
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showOptions = false; onStabilize(current, strength) }) {
                        Text("เริ่มกันสั่น", color = Cyan, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = { TextButton(onClick = { showOptions = false }) { Text("ยกเลิก", color = TextDim) } }
            )
        }
    }
}

@Composable
private fun RoundButton(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    Box(
        Modifier.size(52.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, contentDescription = desc, tint = Color.White, modifier = Modifier.size(24.dp)) }
}

@Composable
private fun PhotoPage(item: MediaItem) {
    val ctx = LocalContext.current
    var bmp by remember(item.uri) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(item.uri) { bmp = Thumbs.load(ctx, item.uri, 1800) }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b == null) CircularProgressIndicator(color = Cyan)
        else Image(
            bitmap = b.asImageBitmap(), contentDescription = null,
            contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun VideoPage(item: MediaItem, active: Boolean) {
    var view by remember { mutableStateOf<VideoView?>(null) }
    var playing by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(active) {
        if (!active) { view?.pause(); playing = false }
    }
    LaunchedEffect(playing, view) {
        while (playing) {
            val v = view
            if (v != null && v.duration > 0) progress = v.currentPosition.toFloat() / v.duration
            delay(200)
        }
    }
    DisposableEffect(Unit) { onDispose { view?.stopPlayback() } }

    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        AndroidView(
            factory = { c ->
                VideoView(c).apply {
                    setVideoURI(item.uri)
                    setOnPreparedListener { seekTo(1) }
                    setOnCompletionListener { playing = false; progress = 0f; seekTo(1) }
                    view = this
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                val v = view ?: return@clickable
                if (v.isPlaying) { v.pause(); playing = false } else { v.start(); playing = true }
            },
            contentAlignment = Alignment.Center
        ) {
            if (!playing) {
                Box(
                    Modifier.size(76.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.PlayArrow, "เล่น", tint = Color.White, modifier = Modifier.size(44.dp)) }
            }
        }
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()
                .padding(start = 24.dp, end = 24.dp, bottom = 84.dp)
        ) {
            Slider(
                value = progress,
                onValueChange = {
                    progress = it
                    val v = view
                    if (v != null && v.duration > 0) v.seekTo((it * v.duration).toInt())
                },
                colors = SliderDefaults.colors(
                    thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                )
            )
        }
    }
}

private fun shareMedia(context: Context, item: MediaItem) {
    runCatching {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = if (item.isVideo) "video/*" else "image/*"
            putExtra(Intent.EXTRA_STREAM, item.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(i, "แชร์").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
