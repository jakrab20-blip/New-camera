package com.steadycam.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF09090E)
val Surface1 = Color(0xFF14141C)
val Surface2 = Color(0xFF1E1E2A)
val Violet = Color(0xFF7C5CFF)
val Cyan = Color(0xFF19D3E8)
val TextDim = Color(0xFF9A9AB0)
val Danger = Color(0xFFFF5A6E)
val AccentBrush = Brush.linearGradient(listOf(Violet, Cyan))

@Composable
fun SteadyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            onPrimary = Color.White,
            background = Bg,
            surface = Surface1,
            onSurface = Color.White,
            onBackground = Color.White
        ),
        content = content
    )
}
